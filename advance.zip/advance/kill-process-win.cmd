@echo off
powershell.exe -ExecutionPolicy Bypass -NoProfile -File "%~dp0kill-process-win.cmd"
