[CmdletBinding()]
param()

$LogFile = "C:\Program Files (x86)\ossec-agent\active-response\active-responses.log"
function Write-ARLog ($msg) {
    $time = (Get-Date).ToString("yyyy/MM/dd HH:mm:ss")
    "$time active-response/kill-process-win: $msg" | Out-File -Append -FilePath $LogFile -Encoding utf8
}

$rawInput = [Console]::In.ReadToEnd()
if (-not $rawInput) { exit 0 }

try {
    $data = $rawInput | ConvertFrom-Json
} catch {
    Write-ARLog "Lỗi phân tích JSON: $_"
    exit 1
}

if ($data.command -ne "add") { exit 0 }

$alert = $data.parameters.alert

# Trích xuất PID từ Sysmon Event ID 1 / Security 4688
$targetPid = $null
if ($alert.data.win.system.processId) { $targetPid = $alert.data.win.system.processId }
elseif ($alert.data.win.eventdata.processId) { $targetPid = $alert.data.win.eventdata.processId }
elseif ($alert.data.process.pid) { $targetPid = $alert.data.process.pid }
elseif ($alert.data.pid) { $targetPid = $alert.data.pid }

# Hỗ trợ đổi định dạng nếu PID là Hex (ví dụ: 0x1f4 -> 500)
if ($targetPid -match "^0x[0-9a-fA-F]+$") {
    $targetPid = [Convert]::ToInt32($targetPid, 16)
}

if (-not $targetPid) {
    Write-ARLog "Bỏ qua: Không tìm thấy trường processId trong cảnh báo."
    exit 0
}

# Danh mục tiến trình hệ thống tuyệt đối không được dừng
$criticalProcesses = @(
    "csrss", "lsass", "smss", "services", "wininit",
    "winlogon", "explorer", "svchost", "wazuh-agent", "wazuh-execd"
)

try {
    $proc = Get-Process -Id $targetPid -ErrorAction Stop
    $procName = $proc.ProcessName.ToLower()

    if ($criticalProcesses -contains $procName) {
        Write-ARLog "[TỪ CHỐI] Không tiêu diệt $procName (PID: $targetPid) vì là tiến trình hệ thống trọng yếu."
        exit 0
    }

    Stop-Process -Id $targetPid -Force
    Write-ARLog "[THÀNH CÔNG] Đã tiêu diệt tiến trình độc hại: $procName (PID: $targetPid)"
}
catch [Microsoft.PowerShell.Commands.ProcessCommandException] {
    Write-ARLog "Tiến trình PID $targetPid đã kết thúc trước đó."
}
catch {
    Write-ARLog "Lỗi khi xử lý PID $targetPid : $_"
}
exit 0