﻿[CmdletBinding()]
param(
    [Parameter(ValueFromPipeline = $true)]
    [string]$RawInput
)

process {
    $LogFile = "C:\Program Files (x86)\ossec-agent\active-response\active-responses.log"
    function Write-ARLog ($msg) {
        $time = (Get-Date).ToString("yyyy/MM/dd HH:mm:ss")
        "$time active-response/kill-process-win: $msg" | Out-File -Append -FilePath $LogFile -Encoding utf8
    }

    if (-not $RawInput) {
        $RawInput = [Console]::In.ReadToEnd()
    }

    if (-not $RawInput) { exit 0 }

    try {
        $data = $RawInput | ConvertFrom-Json
    } catch {
        Write-ARLog "JSON parsing error: $_"
        exit 1
    }

    if ($data.command -ne "add") { exit 0 }

    $alert = $data.parameters.alert

    # Trích xuất Process ID từ các trường sự kiện phổ biến (Sysmon / Windows Security)
    $targetPid = $null
    if ($alert.data.win.system.processId) { $targetPid = $alert.data.win.system.processId }
    elseif ($alert.data.win.eventdata.processId) { $targetPid = $alert.data.win.eventdata.processId }
    elseif ($alert.data.process.pid) { $targetPid = $alert.data.process.pid }
    elseif ($alert.data.pid) { $targetPid = $alert.data.pid }

    # Xử lý nếu PID ở dạng Hexadecimal (ví dụ: 0x1a2b -> int)
    if ($targetPid -match "^0x[0-9a-fA-F]+$") {
        $targetPid = [Convert]::ToInt32($targetPid, 16)
    }

    if (-not $targetPid) {
        Write-ARLog "Skip: Khong tim thay processId hop le trong canh bao."
        exit 0
    }

    # Danh mục tiến trình cốt lõi cần bảo vệ chống màn hình xanh (BSOD)
    $criticalProcesses = @(
        "csrss", "lsass", "smss", "services", "wininit",
        "winlogon", "explorer", "svchost", "wazuh-agent", "wazuh-execd"
    )

    try {
        $proc = Get-Process -Id $targetPid -ErrorAction Stop
        $procName = $proc.ProcessName.ToLower()

        if ($criticalProcesses -contains $procName) {
            Write-ARLog "[TU CHOI] Khong tieu diet $procName (PID: $targetPid) vi la tien trinh he thong cot loi."
            exit 0
        }

        Stop-Process -Id $targetPid -Force
        Write-ARLog "[THANH CONG] Da tieu diet tien trinh: $procName (PID: $targetPid)"
    }
    catch [Microsoft.PowerShell.Commands.ProcessCommandException] {
        Write-ARLog "Tien trinh PID $targetPid da thoat truoc do."
    }
    catch {
        Write-ARLog "Loi khi dung tien trinh PID $targetPid : $_"
    }
    exit 0
}
