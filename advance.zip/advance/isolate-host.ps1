﻿[CmdletBinding()]
param(
    [Parameter(ValueFromPipeline = $true)]
    [string]$RawInput
)

process {
    $LogFile = "C:\Program Files (x86)\ossec-agent\active-response\active-responses.log"
    function Write-ARLog ($msg) {
        $time = (Get-Date).ToString("yyyy/MM/dd HH:mm:ss")
        "$time active-response/win_isolate_host: $msg" | Out-File -Append -FilePath $LogFile -Encoding utf8
    }

    if (-not $RawInput) {
        $RawInput = [Console]::In.ReadToEnd()
    }

    if (-not $RawInput) { exit 0 }

    try {
        $data = $RawInput | ConvertFrom-Json
    } catch {
        Write-ARLog "JSON parsing error: $_"
        exit 1
    }

    $command = $data.command

    # Đọc địa chỉ IP Wazuh Manager từ file ossec.conf
    $confPath = "C:\Program Files (x86)\ossec-agent\ossec.conf"
    $managerIp = ""
    if (Test-Path $confPath) {
        try {
            [xml]$cfg = Get-Content $confPath
            $managerIp = $cfg.ossec_config.client.server.address
        } catch {
            Write-ARLog "Khong doc duoc ossec.conf: $_"
        }
    }

    if ($command -eq "add") {
        Write-ARLog "Nhận lệnh cô lập: Đang tự động BẬT Firewall và thiết lập ngắt mạng..."

        # 1. BẬT TƯỜNG LỬA TRÊN TẤT CẢ PROFILES
        Set-NetFirewallProfile -All -Enabled True | Out-Null

        # 2. Đặt chính sách chặn ngầm định (Drop toàn bộ Inbound và Outbound)
        Set-NetFirewallProfile -Profile Domain,Public,Private -DefaultInboundAction Block -DefaultOutboundAction Block | Out-Null

        # 3. Mở kênh điều khiển độc quyền tới Wazuh Manager (Port 1514)
        if ($managerIp) {
            New-NetFirewallRule -DisplayName "Wazuh_AR_Isolate_Allow_Mgr_TCP" -Direction Outbound -Action Allow -RemoteAddress $managerIp -RemotePort 1514 -Protocol TCP | Out-Null
            New-NetFirewallRule -DisplayName "Wazuh_AR_Isolate_Allow_Mgr_UDP" -Direction Outbound -Action Allow -RemoteAddress $managerIp -RemotePort 1514 -Protocol UDP | Out-Null
            Write-ARLog "Đã whitelist Manager IP: $managerIp:1514"
        }

        # 4. Mở DHCP và Loopback nội bộ
        New-NetFirewallRule -DisplayName "Wazuh_AR_Isolate_Allow_DHCP" -Direction Outbound -Action Allow -Protocol UDP -RemotePort 67,68 | Out-Null
        New-NetFirewallRule -DisplayName "Wazuh_AR_Isolate_Allow_Loopback_In" -Direction Inbound -Action Allow -InterfaceAlias "Loopback Pseudo-Interface 1" -ErrorAction SilentlyContinue | Out-Null
        New-NetFirewallRule -DisplayName "Wazuh_AR_Isolate_Allow_Loopback_Out" -Direction Outbound -Action Allow -InterfaceAlias "Loopback Pseudo-Interface 1" -ErrorAction SilentlyContinue | Out-Null

        Write-ARLog "Đã cô lập host thành công (Firewall: ON, DefaultOutbound: Block)."
    }
    elseif ($command -eq "delete") {
        Write-ARLog "Hết timeout hoặc nhận lệnh gỡ bỏ: Đang TẮT Firewall và khôi phục FlareVM..."

        # 1. Xóa toàn bộ các rule ngoại lệ đã tạo
        Get-NetFirewallRule -DisplayName "Wazuh_AR_Isolate_*" -ErrorAction SilentlyContinue | Remove-NetFirewallRule

        # 2. Khôi phục DefaultOutboundAction về Allow
        Set-NetFirewallProfile -Profile Domain,Public,Private -DefaultInboundAction Block -DefaultOutboundAction Allow | Out-Null

        # 3. TẮT TƯỜNG LỬA TRẢ VỀ NGUYÊN TRẠNG CHO FLAREVM
        Set-NetFirewallProfile -All -Enabled False | Out-Null

        Write-ARLog "Đã khôi phục mạng thành công (Firewall: OFF)."
    }
    exit 0
}
