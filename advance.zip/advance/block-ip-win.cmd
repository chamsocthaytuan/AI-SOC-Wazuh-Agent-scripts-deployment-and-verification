@echo off
powershell.exe -ExecutionPolicy Bypass -NoProfile -File "%~dp0block-ip.ps1"
