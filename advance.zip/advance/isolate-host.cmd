@echo off
powershell.exe -ExecutionPolicy Bypass -NoProfile -File "%~dp0isolate-host.ps1"
