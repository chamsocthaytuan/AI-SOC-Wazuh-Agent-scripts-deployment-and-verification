﻿[CmdletBinding()]
param(
    [Parameter(ValueFromPipeline = $true)]
    [string]$RawInput
)

process {
    $LogFile = "C:\Program Files (x86)\ossec-agent\active-response\active-responses.log"
    function Write-ARLog ($msg) {
        $time = (Get-Date).ToString("yyyy/MM/dd HH:mm:ss")
        "$time active-response/win_block_ip: $msg" | Out-File -Append -FilePath $LogFile -Encoding utf8
    }

    # Ho tro nhan tu pipeline hoac doc tu standard input
    if (-not $RawInput) {
        $RawInput = [Console]::In.ReadToEnd()
    }

    if (-not $RawInput) { exit 0 }

    try {
        $data = $RawInput | ConvertFrom-Json
    } catch {
        Write-ARLog "JSON parsing error: $_"
        exit 1
    }

    $command = $data.command
    $alert = $data.parameters.alert

    # Trich xuat srcip tu cac vi tri pho bien trong alert
    $srcip = $null
    if ($alert.data.srcip) { $srcip = $alert.data.srcip }
    elseif ($alert.data.win.eventdata.ipAddress) { $srcip = $alert.data.win.eventdata.ipAddress }
    elseif ($alert.srcip) { $srcip = $alert.srcip }
    elseif ($alert.data.src_ip) { $srcip = $alert.data.src_ip }

    if (-not $srcip -or $srcip -eq "-" -or $srcip -eq "127.0.0.1") {
        Write-ARLog "Skip: Valid srcip not found in alert."
        exit 0
    }

    $ruleName = "Wazuh_AR_Block_$srcip"

    if ($command -eq "add") {
        $exists = Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue
        if (-not $exists) {
            New-NetFirewallRule -DisplayName $ruleName -Direction Inbound -Action Block -RemoteAddress $srcip -Description "Auto blocked by Wazuh AR" | Out-Null
            Write-ARLog "Successfully created Firewall Rule to block IP: $srcip"
        } else {
            Write-ARLog "Rule already exists for IP: $srcip"
        }
    }
    elseif ($command -eq "delete") {
        Remove-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue
        Write-ARLog "Successfully removed Firewall Rule for IP: $srcip"
    }
    exit 0
}
